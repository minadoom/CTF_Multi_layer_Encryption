import base64
from itertools import cycle

def encode_message(message: str) -> str:
    """
    Encodes a message using multiple layers:
    1. The missing layer you should fix
    2. Base64 encode
    3. Custom substitution
    """
    # First layer of encoding
    # find the fist layer logic
    
    # Second layer
    b64_encoded = base64.b64encode(xored.encode()).decode()
    
    # Third layer - substitution
    substitution = str.maketrans(
        "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
        "QWERTYUIOPASDFGHJKLZXCVBNMqwertyuiopasdfghjklzxcvbnm9876543210_-"
    )
    return b64_encoded.translate(substitution)